function R= RelayOutput(prev, curr, alpha, beta, h,state)
e= curr-prev;
if(e>0)
    if(curr>alpha+h/2)
        R=1;
    else
        R=state;
    end
end
if(e<0)
    if(curr<beta-h/2)
        R=-1;
    else
        R=state;
    end
end
    
    


