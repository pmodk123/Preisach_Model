function [alpha,beta, h] = GridCalculator(Umin, Umax, n)
h= (Umax-Umin)/n;
N= n*(n+1)/2;
alpha= zeros(1, N);
beta= zeros(1, N);
j=1;
for a= Umax-h/2:-h:Umin+h/2
    for b= Umin+h/2: h: a
        alpha(j)= a;
        beta(j)= b;
        j= j+1;
    end
end


   