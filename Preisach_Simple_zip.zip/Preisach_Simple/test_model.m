clc
clear all

data = readmatrix("Dataset.csv");
x = data(:,1);
y = data(:,2);
x = x*100;
y = y*100;

x = transpose(x);
y = transpose(y);

vals = [13.93,18.54,81.07,104.91];

n = 200;
Umin = 0;
Umax = 100;

[alpha, beta, h]= GridCalculator_bt(Umin, Umax, n);
[mu,matrix]= Preisach_bt(Umin, Umax, x, y, n, alpha, beta, h,vals);
mu

out = matrix*mu;

plot(x,y,'g')
hold on
plot(x,out,'r')
hold off

