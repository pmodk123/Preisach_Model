function [mu, Matrix,resnorm,residual]= Preisach(Umin, Umax, x, y, n, alpha, beta , h)
N= n*(n+1)/2;
p= size(x);
n_data= p(1, 2);
state=zeros(1,N);

for i=1:N
    state(i)=-1;
end

Matrix= zeros(n_data, N);

prev=Umin-1;
curr= Umin;
for i= 1:n_data
    curr= x(i);
    for j= 1:N
        Area= 0;
        if(alpha(j)==beta(j))
            Area= (h*h)/2;
        else
            Area= h*h;
        end
        state(j)=RelayOutput(prev,curr,alpha(j),beta(j),h,state(j));
        Matrix(i, j)= Area*state(j);
    end
    prev= curr;
end

z= transpose(y);
[mu,resnorm,residual] = lsqnonneg(Matrix,z);
    
    







