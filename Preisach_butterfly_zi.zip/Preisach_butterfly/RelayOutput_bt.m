%*** This function return the state of hysteron for current input ***%
function R = RelayOutput_bt(prev, curr, alpha, beta, h, state,j,vals)
    e= curr-prev;
    R = state(j);
    
    if(e>0) %Input is being increased i.e. forward traversal of loop
        if(curr>(alpha+h/2)) 
            if(curr>=vals(1)) && (curr<=vals(3))
                R = -1;
            else
                R = 1;
            end
        else 
            R = state(j);
        end
    end

    if(e<0) %reverse traversal of loop
        if(curr<(beta-h/2))
            if(curr<vals(4)) && (curr>vals(2))
                R = -1;
            else
                R = 1;
            end
        else
            R = state(j);
        end
    end

