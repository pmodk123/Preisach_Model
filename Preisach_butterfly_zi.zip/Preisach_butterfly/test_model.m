% clear all
% close all
clc

%Symmetrical Dataset
%***
% data = readmatrix("dataset1.csv","Range",'A2:B264');
% x = data(:,1);
% y = data(:,2);
% vals = [-176.7,-58.7,65.62,191];
% Umin = -200;
% Umax = 200;
%***

%Experimental Dataset
%***
data = readmatrix("dataset4.csv","Range",'A2:B99');
x = data(:,1);
y = data(:,2);
vals = [-148.76,-111,116,180];
Umin = -190;
Umax = 190;
%***

x = transpose(x);
y = transpose(y);

n = 20;

[alpha, beta, h]= GridCalculator(Umin, Umax, n);
[mu,matrix]= Preisach(Umin, Umax, x, y, n, alpha, beta, h,vals);
mu;

out = matrix*mu;

plot(x,y,'g')
xlabel('Electric field (kV/cm)');
ylabel('Strain(nm)');
hold on
plot(x,out,'r')
% xlabel('xdata');
% ylabel('ydata');
legend("real output","model output","location","north")
title('For n = 20');
hold off
