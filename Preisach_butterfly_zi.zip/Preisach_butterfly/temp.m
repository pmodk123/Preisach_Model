
k = 1;

data = zeros(n,n);
for i=1:n
    for j=1:n
        if (j<=n+1-i) 
            data(i,j) = mu(k);
            k = k+1;
        else data(i,j) = nan;
        end
    end
end


heatmap(data,'MissingDataColor', 'w', 'GridVisible', 'off', 'MissingDataLabel', " ")
title('Heatmap for hysteron weights')
Ax = gca;
Ax.XDisplayLabels = nan(size(Ax.XDisplayData));
Ax.YDisplayLabels = nan(size(Ax.YDisplayData));