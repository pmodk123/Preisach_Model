function [mu,Matrix] = Preisach(Umin, Umax, x, y, n, alpha, beta , h, vals)
    N= n*(n+1)/2;  %Total number of hysterons in preisach plane
    p = size(x);
    n_data= p(1, 2);
    Matrix= zeros(n_data, N);

    state = zeros(1,N);  %Initialize a state vector for storing hysteron state

    for i=1:N
        if(beta(i)<=vals(1)) state(i) = 1;
        end
    end

    prev=Umin;
    
    for i= 1:n_data
        curr= x(i);
        for j= 1:N
            
            Area = 0;
            if(alpha(j)==beta(j))
                Area= h*h/2;   
            else
                Area= h*h;
            end
       
            state(j) = RelayOutput_bt(prev,curr,alpha(j),beta(j),h,state,j,vals);

            Matrix(i, j)= Area*state(j);
        end
        prev= curr;
    end

    Matrix;

    z= transpose(y);

    lb = -2*ones(1,N); %Lower bound for weights of mu
    ub = 2*ones(1,N);  %Upper bound for weights of mu

    mu = lsqlin(Matrix,z,[],[],[],[],lb,ub);

 